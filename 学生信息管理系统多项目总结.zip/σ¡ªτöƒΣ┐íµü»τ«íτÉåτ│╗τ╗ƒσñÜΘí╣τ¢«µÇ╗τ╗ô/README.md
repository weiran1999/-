## 对于报错

第一个报错
进入文件夹环境

在settings.py配置文件中，添加pymysql的配置


>import pymysql
>
>pymysql.install_as_MySQLdb()

第二次报错

在项目目录下__init__.py文件中输入如下代码：

>import pymysql
>
>pymysql.version_info = (1, 4, 13, "final", 0)
>
>pymysql.install_as_MySQLdb()

对captcha报错

>pip install django-simple-captcha

## 启动配置

>python manage.py make-migrations

通常会报错： No changes detected 

输入如下
>python manage.py makemigrations --empty course

enmty yourappname yourappname 是你的app的名字，这里可以是一个自己创立的空文件夹。

然后迁移数据库，很多时候可以一步到这，不必上述步骤。

>python manage.py migrate

#启动服务端，无需迁移的情况直接跑框架：

>python manage.py runserver 0.0.0.0:8000

登陆网址：
>http://127.0.0.1:8000/login

## 对于各个项目总结

GUI-easy_system，最简单，一个py文件，GUI库TK与pymysql的结合，麻雀虽小，五脏俱全。
***
GUI-Stu_System，纯GUI，数据由txt读写。各个部分有分离。
***
StudentSystem ，建议Django框架，入门级别的编写。很容易看懂，相对符合规律。

```
├── StudentSystem
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── manage.py
├── studentManagement
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── migrations
│   │   ├── 0001_initial.py
│   │   └── __init__.py
│   ├── models.py
│   ├── tests.py
│   ├── urls.py
│   └── views.py
└── templates
    └── studentManage
        ├── add.html
        ├── delete.html
        ├── index.html
        ├── login.html
        ├── select.html
        └── update.html
```

如上，StudentSystem文件夹中，setting是注册app和库的使用。其他俩个应该为自行创建的。

- studentManagement中，admin为了超级管理用户而见。然后填写内容，就可以通过vip用户管理后台了。命令行：
>python manage.py createsuperuser

- apps，tests常规。
- urls作为路由跳转。
- models作为数据库结构构造，也负责了主键约束。
- views负责视图函数。也负责交互这一块，增删改查。
- migration里面的00001initial负责了数据库迁移后，哪个库对上那些数据。
- templates里面都是负责前端的超文本文件。

***
studentCourse 这个项目稍微复杂些，部分我也没弄明白。

forms.py是负责表单交互的功能。其中多了验证码功能，验证码可以去注释掉一行代码而取消。




